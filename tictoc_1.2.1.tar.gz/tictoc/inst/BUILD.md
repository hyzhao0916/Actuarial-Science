## Requirements
```
R CMD install devtools
sudo port install texlive
sudo port install texlive-fonts-extra
sudo port install pandoc
```
