tictoc
======

R package with extended timing functions tic/toc,
as well as classes Stack (a stack implemented as a vector)
and StackList (a stack implemented as a list).
See http://jabiru.github.io/tictoc/ for more detail.
